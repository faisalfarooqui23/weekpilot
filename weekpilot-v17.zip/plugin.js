PluginAPI.registerHeaderButton({
  id: 'weekpilot-open',
  label: 'WeekPilot',
  icon: 'event_available',
  onClick: () => PluginAPI.showIndexHtmlAsView()
});
